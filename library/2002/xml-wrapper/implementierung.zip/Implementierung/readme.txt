The XMLWrapper application is still in a beta phase. 

You can use it but nobody will guarantee for anything !!!

If you plan to use things commercially contact me 
at robert.soesemann@student.uni-tuebingen.de 

###################### INSTRUCTIONS #########################

To start the XMLWrapper application adjust the XMLWrapper.bat batch file 
for your own purposes. You find this file in the /bin subdirectory.

Open this file an change to path directions to query, descriptor an output path.
Don't change the -D java directive. Without it won't work.

To test the wrapper you can use datasources an queries from the /examples subdirectory.

The java source code as well as an JAVADOC documentation of the classes can be 
found in the /src and /doc subdirectories.

FOR MORE INFORMATION on this projekt read the relevant document at 
www.webspace-journey.de/openproject.


