package org.uni_tuebingen.wsi.xmlwrapper;

import java.util.*;       //include List, ArrayList, Arrays
import org.jdom.Element;
import org.jdom.Attribute;

/**
 * An instance of <code>Boolean</code> represents a <code><boolean></code>
 * element in a common query uses by the <code>XMLWrapper</code> application.
 *
 * The constructor acts as parsing module which checks the correct syntax of the
 * incoming tree element.
 *
 *
 * @author Robert S�semann, <robert.soesemann@student.uni-tuebingen.de>
 * @version 1.0, 23.03.02
 */

public class Boolean
{
  private static final String[] VALIDOP = {"and", "or", "and-not"};


  /**
   * Parses the incoming XML tree fragment (=an element) for correct <code><boolean></code>
   * syntax and builds an internal representation.
   * To parse its subcomponents of (term, boolean) another method is called.
   *
   * @param booleanElement a JDOM <code>Element</code> that holds a tree fragment
   * @throws XMLWrapperException is thrown when syntax error occurs
   */
  public Boolean(Element booleanElement) throws XMLWrapperException
  {
	List children =	booleanElement.getChildren();
	if(children.isEmpty() || children.size()!=2)
	  throw new XMLWrapperException("<boolean> must have 2 children", -48);

	Element f = (Element) children.get(0);
	Element s = (Element) children.get(1);

	first = parseTermOrBoolean(f);
	second = parseTermOrBoolean(s);
	operator = parseOperator(booleanElement);
  } //constructor


  /**
   * As helper method of the constructor, <code>parseTermOrBoolean</code> calles the
   * required parsing methods for a <code><boolean></code>'s subcomponents.
   *
   * @param subelement an JDOM <code>Element</code> that either hold a <term> or <boolean> tree fragment
   * @return <code>Object</code>, that wraps <code>Term</code> or <code>Boolean</code> instance
   * @throws XMLWrapperException is thrown when syntax error occurs
   */
  private Object parseTermOrBoolean(Element subelement) throws XMLWrapperException
  {
	Object tmp;
	if(subelement.getName().equals("term"))
	  tmp = new Term(subelement);
	else if(subelement.getName().equals("boolean"))
	  tmp = new Boolean(subelement);
	else
	  throw new XMLWrapperException(subelement.getName() + " is an invalid child of <boolean>", -49);

	return tmp;
  } //parseTermOrBoolean


  /**
   * As helper method of the constructor, parses and sets the internal representation
   * of this <code><boolean></code>'s operator
   *
   * @param booleanElement an JDOM <code>Element</code> that either hold a <term> or <boolean> tree fragment
   * @throws XMLWrapperException is thrown when syntax error occurs
   */
  public String parseOperator(Element booleanElement) throws XMLWrapperException
  {
	String tmp;

	Attribute attribute = booleanElement.getAttribute("op");
	if(attribute == null)
	  throw new XMLWrapperException("<boolean> is missing an 'op' attribute", -50);
	else
	{
	  String value = attribute.getValue();
	  ArrayList valueList = new ArrayList(Arrays.asList(VALIDOP));
	  if(valueList.contains(value))
		tmp = value;
	  else
		throw new XMLWrapperException(value + " can not be value of attribute op in <boolean>", -51);
	} //else

	return tmp;
  } //parseOperator


  /**
   * This method is part of the recursive composition of the XSLT expression, that
   * maps the common query's condition to XSLT syntax.
   * The booleans subcomponents are combined by the XSLT counterpart of the common
   * query's operator.
   * The string representation of the subcomponents themselves is maintained by calling
   * their <code>toXSLTPattern()</code> methods
   *
   * @param sofar <code>String</code> that hold part of the XSLT pattern, that was
   * generated yet during recursive calls of this method
   * @param sourceProperties <code>HashMap</code> holding essential information needed for calling
   * that method on a <code>Term</code> element (see.: <code>Term</code> javadoc)
   *
   * @return XSLT conform, source specific <code>String</code> representation of this <boolean>
   * @throws XMLWrapperException needed to pass Exception that can be thrown by
   * calling that method on a <code>Term</code> elementby a <code>Term</code>
   */
  public String toXSLTPattern(String sofar , HashMap sourceProperties) throws XMLWrapperException
  {
	String firstPattern;
	String secondPattern;

	if(first instanceof Term) firstPattern = ((Term) first).toXSLTPattern("", sourceProperties);
	else firstPattern = ((Boolean) first).toXSLTPattern("", sourceProperties);
	if(second instanceof Term) secondPattern = ((Term) second).toXSLTPattern("", sourceProperties);
	else secondPattern = ((Boolean) second).toXSLTPattern("", sourceProperties);

	// special conversion needed for 'and-not'
	if(operator.equals("and-not"))
	  sofar += "(" + firstPattern + " and not(" + secondPattern + "))";
	else
	  sofar += "(" + firstPattern + " " + operator + " " + secondPattern + ")";
	return sofar;
  } //toXSLTPattern


  /**
   * Returns this <code>Boolean</code>'s operator
   * @return the <code>String</code> value of <code>operator</code>
   */
  public String getOperator()
  { return operator; }


  /* holds the components of a <boolean> */
  private Object first = null;
  private Object second = null;
  private String operator;

} //Boolean