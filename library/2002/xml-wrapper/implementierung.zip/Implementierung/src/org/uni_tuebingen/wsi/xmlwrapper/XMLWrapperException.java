package org.uni_tuebingen.wsi.xmlwrapper;

import java.io.PrintStream;
import java.io.PrintWriter;

/**
 * <b><code>XMLWrapperException</code></b> represents and wraps all exceptions
 * that can occur during the work of the <code>XMLWrapper</code> application.
 *
 * If a foreign subclass throws an exception (e.g. URL), this class helps to give
 * meaningful error message by catching and passing the message to a level where
 * the reason can be made clearer.
 *
 * This kind of exception is also thrown when errors occur that are part of the
 * functionality of this application (e.g. parsing errors, parameter errors)
 *
 * @author Robert S�semann, <robert.soesemann@student.uni-tuebingen.de>
 * @version 1.0, 23.03.02
 */

public class XMLWrapperException extends Exception
{
    /** A wrapped <code>Throwable</code> */
    protected Throwable rootCause;

    /**
     * default <code>Exception</code>
     */
    public XMLWrapperException()
	{ super("aborted due to unknown error"); }


    /**
     * This will create an <code>XMLWrapperException</code> with the given message.
	 *
     * @param message <code>String</code> message indicating the problem that occurred.
     */
    public XMLWrapperException(String message, int code)
	{
	  super(message);
	  this.code = code;
	}


    /**
     * This returns the message for the <code>XMLWrapperException</code>. If
     * there is a root cause, the message associated with the root
     * <code>Exception</code> is appended.
     *
     * @return <code>String</code> - message for <code>Exception</code>.
     */
    public String getMessage()
	{
        if (rootCause != null)
          return super.getMessage() + ": " + rootCause.getMessage();
  		else
          return super.getMessage();
    } //getMessage


    /**
     * This returns the error code for the <code>XMLWrapperException</code>.
     *
     * @return <code>String</code> - error code attached to this <code>XMLWrapperException</code>.
     */
    public int getCode()
	{
	  return code;
    } //getCode


    /**
     * This prints the stack trace of the <code>XMLWrapperException</code>. If
     * there is a root cause, the stack trace of the root
     * <code>Exception</code> is printed right after.
     */
    public void printStackTrace()
	{
        super.printStackTrace();
        if (rootCause != null)
		{
            System.err.print("Root cause: ");
            rootCause.printStackTrace();
        }
    } //printStackTrace


    /**
     * This prints the stack trace of the <code>Exception</code> to the given
     * PrintStream. If there is a root cause, the stack trace of the root
     * <code>Exception</code> is printed right after.
     */
    public void printStackTrace(PrintStream s)
	{
        super.printStackTrace(s);
        if (rootCause != null)
		{
            s.print("Root cause: ");
            rootCause.printStackTrace(s);
        }
    } //printStackTrace


    /**
     * <p>
     * This prints the stack trace of the <code>Exception</code> to the given
     *   PrintWriter. If there is a root cause, the stack trace of the root
     *   <code>Exception</code> is printed right after.
     * </p>
     */
    public void printStackTrace(PrintWriter w)
	{
        super.printStackTrace(w);
        if (rootCause != null)
		{
            w.print("Root cause: ");
            rootCause.printStackTrace(w);
        }
    } //printStackTrace


    /**
     * <p>
     * This will return the root cause <code>Throwable</code>, or null
     *   if one does not exist.
     * </p>
     *
     * @return <code>Throwable</code> - the wrapped <code>Throwable</code>.
     */
    public Throwable getRootCause()
	{ return rootCause; }

	// error code that will be provided to the information broker
	int code;

} //XMLWrapperException
