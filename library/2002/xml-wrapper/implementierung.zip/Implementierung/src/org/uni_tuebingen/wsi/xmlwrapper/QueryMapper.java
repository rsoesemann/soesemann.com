package org.uni_tuebingen.wsi.xmlwrapper;

import java.util.*;       //include Iterator, HashMap, ArrayList

import org.jdom.Document;
import org.jdom.input.DOMBuilder;
import org.jdom.output.XMLOutputter;

import org.jdom.transform.*;
import javax.xml.transform.*;

/**
 * <code>QueryMapper</code> performs the main task of mapping a common query  to a specific
 * XML data source by the help of a file that holds meta information on hwo to do the
 * mapping. It is part of the <code>XMLQWrapper</code> application.
 * <p>
 * To easily handle and access the query's and sourcedescriptor's information internal representation
 * are build (=instances of java classes):
 * <p>
 * <ul>
 *  <li><code>CommonQuery</code>, <code>Boolean</code>, <code>Term</code> to parse
 *  and access the information of the query and its subcomponents</li>
 * <li><code>XMLSourceDescriptor</code>, <code>Property</code> to parse and access
 *  the information of the source-descriptor </li>
 * </ul>
 *
 * @author Robert S�semann, <robert.soesemann@student.uni-tuebingen.de>
 * @version 1.0, 23.03.02
 */

public class QueryMapper
{

  /**
   * Constructs a <code>QueryMapper</code> by assigning its XMLSourceDescriptor
   * This means: every instance of an <code>QueryMapper</code> is only able to map
   * queries to the one XML data source described by the attached <code>XMLSourceDescriptor</code>.
   *
   * @param d the XMLSourceDescription for this <code>QueryMapper</code>
   */
  public QueryMapper(XMLSourceDescriptor d)
  {
	descriptor = d;
	builder = new DOMBuilder(XMLWrapper.DOMADAPTER);
  } //constructor


  /**
   * Submits a query to an XML source document and returns a result document.
   * The source to submit queries is defined by the <code>XMLSourceDescriptor</code>
   * which was provided to the constructor.
   * This method does not perform the actual query execution. It just acts as a public
   * wrapper to hide all the tasks (e.g. map system query to XSLT stylesheet, install Xalan
   * processor, handle in and output as stream and perform transformation from user.
   *
   * @param query an <code>CommonQuery</code> object representing the unmapped system query
   * @return JDOM <code>Document</code>
   * @throws <code>Exception</code> will be caught by the main() in <code>XMLWrapper</code>
   */
  public Document executeQuery(CommonQuery commonQuery) throws Exception
  {
    HashMap propertiesMap = descriptor.getPropertiesMap();
    Iterator iterator = propertiesMap.values().iterator();
    ArrayList outerProperties = new ArrayList();
    boolean hasOuters = false;
    StringTokenizer tokenizer;

    // handle outer properties seperately
    while(iterator.hasNext()) 
    {
      Property p = (Property) iterator.next();

      if(p.getOuter().equals("true")) 
      {
        hasOuters = true;

        // if mapTo belongs to complex 'any' fieldname
        if(p.getMapto().indexOf(",")!=-1) 
        {
          tokenizer = new StringTokenizer(p.getMapto(), ",");

          while(tokenizer.hasMoreTokens()) {
                  outerProperties.add(new String(tokenizer.nextToken().trim()));
          }//while
        }//if
        
        // else if mapTo is single value
        else outerProperties.add(new String(p.getMapto()));
     }//if
    }//while

    String condition = commonQuery.toXSLTPattern("", propertiesMap);
    String infoUnit = descriptor.getInfounit();
    String resultdtd_url = descriptor.getResultdtd_url();
    // get actual source XML file
    JDOMSource source = new JDOMSource(builder.build(descriptor.getSource_url()));

    // eventually overwrite source with flattened copy 
    if(hasOuters) {
            XMLSourceFlattener flattener = 
            new XMLSourceFlattener(source, infoUnit);
            source = new JDOMSource(flattener.flatten(outerProperties));
    }//if
    // return query result provided by XSLT
    XSLTQuery xsltQuery = new XSLTQuery(source, infoUnit, resultdtd_url);
    
    return xsltQuery.execute(condition);
  }  //executeQuery


  private DOMBuilder builder;
  private XMLSourceDescriptor descriptor;
} //QueryMapper