package org.uni_tuebingen.wsi.xmlwrapper;

import java.io.InputStream;
import java.net.URL;
import java.util.*;       // include HashMap, List, Iterator

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.DOMBuilder;

/**
 * An instance of <code>XMLSourceDescriptor</code> represents an XML file
 * that holds meta information about an XML source document. It is used in the
 * <code>XMLWrapper</code> applicationto to map a generic common query to a
 * specific source. the <code>XMLWrapper</code> application.
 *
 * After parsing its syntax an instance of this class holds an easy-to-access
 * representation of the source describing information.
 *
 * @author Robert S�semann, <robert.soesemann@student.uni-tuebingen.de>
 * @version 1.0, 23.03.02
 */

public class XMLSourceDescriptor
{

  /**
   * The incoming <code>InputStream</code>is converted to an JDOM document
   * and parsed for correct <code><XMLSourceDescriptor></code> syntax to builds an internal
   * representation.
   * To parse its subelement and their attributes several parse methods are called.
   * Only to parse an hold the information of a single property an extra object is called.
   *
   * @param is <code>InputStream</code> that holds an XML Document
   * @throws Exception is thrown by JDOM methods or when syntax error occurs
   */
  public XMLSourceDescriptor(InputStream is) throws Exception
  {
	DOMBuilder builder = new DOMBuilder(XMLWrapper.DOMADAPTER);
	Document validDescriptorDoc = builder.build(is);
	Element root = validDescriptorDoc.getRootElement();
	if(!(root.getName().equals("XMLSourceDescriptor")))
	  throw new XMLWrapperException("root element of source descriptor is not <XMLSourceDescriptor>", -30);

	description = parseDescription(root);
	source_url = parseSource_url(root);
	infounit = parseInfounit(root);
	resultdtd_url = parseResultdtd_url(root);
	properties = parseProperties(root);
  } //constructor


  /**
   * Parses descriptive text from XMLSourceDescriptor XML file and make an
   * internal copy.
   *
   * @param root JDOM <code>Element</code> that hold this element
   * @return <code>String</code> with descriptive text
   * @throws XMLWrapperException
   */
  private String parseDescription(Element root) throws XMLWrapperException
  {
	Element e = root.getChild("description");
	if(e==null)
	  return "";

	return e.getText();
  } //parseDescription

  /**
   * Returns the source's description stored in this <code>XMLSourceDescriptor</code>
   * @return the <code>String</code> value of <code>description</code>
   */
  public String getDescription()
  { return description; }


  /**
   * Parses <code>URL</code> to original source document and make an internal copy.
   *
   * @param root JDOM <code>Element</code> that hold this element
   * @return <code>URL</code> of this <source_url> element
   * @throws Exception thrown by wrong <code>URL</code>RL or wrong syntax
   */
  private URL parseSource_url(Element root) throws Exception
  {
	Element e = root.getChild("source-url");
	if(e==null)
	  throw new XMLWrapperException("source descriptor needs <source_url> element", -31);

	return (new URL(e.getTextNormalize()));
  } //parseSource_url

  /**
   * Returns the source's location stored in this <code>XMLSourceDescriptor</code>
   * @return the <code>URL</code> value of <code>location</code>
   */
  public URL getSource_url()
  { return source_url; }


  /**
   * Parses <infounit> element and make an internal copy.
   *
   * @param root Jdom <code>Element</code> that hold this element
   * @return <code>java.utils.Vector</code> of one or more <code>URL</code>s
   * @throws XMLWrapperException is thrown when syntax error occurs
   */
  private String parseInfounit(Element root) throws XMLWrapperException
  {
	Element e = root.getChild("infounit");
	if(e==null)
	  throw new XMLWrapperException("source descriptor needs <infounit> element", -32);

	String tmp = e.getTextNormalize();
	if(tmp.equals(""))
	  throw new XMLWrapperException("source descriptor needs non-empty <infounit> element", -33);

	return tmp;
  } //parseInfounit

  /**
   * Returns the infounit stored in this <code>XMLSourceDescriptor</code>
   * @return the <code>String</code> value of <code>infounit</code>
   */
  public String getInfounit()
  { return infounit; }


  /**
   * Parses <code>URL</code> to DTD of the result document and make an internal copy.
   *
   * @param root JDOM <code>Element</code> that hold this element
   * @return <code>URL</code> of this <source_url> element
   * @throws Exception thrown by wrong <code>URL</code> or wrong syntax
   */
  private URL parseResultdtd_url(Element root) throws Exception
  {
	Element e = root.getChild("resultdtd-url");
	if(e==null)
	  throw new XMLWrapperException("source descriptor needs <resultdtd-url> element",-34);

	String tmp = e.getTextNormalize();
	if(tmp.equals(""))
	  throw new XMLWrapperException("source descriptor needs non-empty <resultdtd-url> element", -35);

	return new URL(tmp);
  } //parseResultdtd_url

  /**
   * Returns the <code>URL</code> to the DTD of the result document stored in this <code>XMLSourceDescriptor</code>
   * @return the <code>URL</code> value of <code>resultdtd_url</code>
   */
  public String getResultdtd_url()
  { return resultdtd_url.toString(); }


  /**
   * Parses the sourounding <property> element of a <XMLSourceDescriptor> and build
   * internal representation of its <property> subelements as a <code>HashMap</code>.
   * To parse the subelements instances of <Property> are created.
   *
   * @param root JDOM <code>Element</code> that hold this element
   * @return <code>HashMap</code> that hold all <property>'s
   * @throws XMLWrapperException thrown if syntax error occurs
   */
  private HashMap parseProperties(Element root) throws XMLWrapperException
  {
	HashMap tmp = new HashMap();
	Element e = root.getChild("properties");

	if(e==null)
	  throw new XMLWrapperException("source descriptor needs <properties> element", -36);

	List properties = e.getChildren("property");
	Iterator iterator = properties.iterator();

	while(iterator.hasNext())
	{
	 Property p = new Property((Element) iterator.next());
	 tmp.put(p.getField(), p);
	}

	return tmp;
  } //parseProperties

  /**
   * Returns the properties stored in this <code>XMLSourceDescriptor</code>
   * @return the <code>HahMap</code> containing the <property> elements.
   */
  public HashMap getPropertiesMap()
  { return properties; }


  /* internal representation of this <XMLSourceDescriptor> */
  private String description;
  private URL source_url;
  private String infounit;
  private URL resultdtd_url;
  private HashMap properties;

} //CommonQuery