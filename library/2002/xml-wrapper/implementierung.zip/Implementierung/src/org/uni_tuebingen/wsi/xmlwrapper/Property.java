package org.uni_tuebingen.wsi.xmlwrapper;

import org.jdom.Element;
import org.jdom.Attribute;

/**
 * An instance of <code>Property</code> represents a <code><property></code>
 * element in a <XMLSourceDescriptor> used by the <code>XMLWrapper</code> application.
 *
 * The constructor constructs this internal representation after calling parser
 * methods on the incoming tree fragment, that check the syntax of the
 * <code>Property</code> subcomponents.
 *
 * @author Robert S�semann, <robert.soesemann@student.uni-tuebingen.de>
 * @version 1.0, 23.03.02
 */

public class Property
{
  /**
   * Calls parser method to check syntax of this <property> and constructs
   * internal representation of a <property>
   *
   * @param propertyElement the JDOM <code>Element</code> that holds the property
   * @throws XMLWrapperException thrown by other method
   */
  public Property(Element propertyElement) throws XMLWrapperException
  {
	field = parseAttribute("field", propertyElement);
	mapto = parseAttribute("mapto", propertyElement);
	outer = parseAttribute("outer", propertyElement);
	description = parseAttribute("description", propertyElement);
  } //constructor


  /**
   * Generic setter method for all internal representations of a <property>'s attributes.
   * This is only called by the constructor to copy the information of an JDOM
   * element.
   *
   * @param name <code>String</code> the attributes name, whose value should be copied
   * @return <code>String</code> parsed attribute value
   * @throws XMLWrapperException
   */
  public String parseAttribute(String name, Element propertyElement) throws XMLWrapperException
  {
	if(name.equals("description"))
	    return propertyElement.getTextNormalize();

	Attribute attribute = propertyElement.getAttribute(name);
	if(attribute==null && !name.equals("outer"))
	  throw new XMLWrapperException("<property> is missing " + name + " attribute", -37);
	else if(attribute==null && name.equals("outer"))
	  return "false";
	else
	{
	  String attributeValue = attribute.getValue();

	  if(name.equals("outer") && !attributeValue.equals("true") && !attributeValue.equals("false"))
	    throw new XMLWrapperException("<property>'s outer attribute must be 'true'/'false'/EMPTY", -38);
	  else
	    return attributeValue;
	}
  } //parseAttribute


  /**
   * Returns the <code>field</code> of this <code>Property</code>
   * @return the <code>String</code> value of <code>field</code>
   */
  public String getField()
  { return field; }

  /**
   * Returns the <code>mapto</code> of this <code>Property</code>
   * @return the <code>String</code> value of <code>mapto</code>
   */
  public String getMapto()
  { return mapto; }

  /**
   * Returns the <code>outer</code> of this <code>Property</code>
   * @return the <code>String</code> value of <code>outer</code>
   */
  public String getOuter()
  { return outer; }

  /**
   * Returns the description of this <code>Property</code>
   * @return the <code>String</code> value of <code>description</code>
   */
  public String getDescription()
  { return description; }


  /* internal representation of a term elements attributes */
  private String field;
  private String mapto;
  private String outer = "false"; //by default if not provided
  private String description;

} //Property
