package org.uni_tuebingen.wsi.xmlwrapper;

/* Standard JDK */
import java.io.*;           // include File, InputStream, PrintWriter
import java.net.URL;
import java.util.Date;

/* ORO NetComponents for FTP Up-/Download */
import com.oroinc.net.ftp.FTPClient;
import com.oroinc.net.ftp.FTPReply;

/* JDOM Classes */
import org.jdom.Document;
import org.jdom.Namespace;
import org.jdom.output.XMLOutputter;

/**
 * <code>XMLWrapper</code> acts as wrapper component of an Information Broker system which lets users
 * submit queries on heterogenious XML data sources.
 * <p>
 * It works as an independant, stand-alone utility program, which accepts
 * the following parameters:
 * <ol>
 *  <li>descriptorURL: <code>URL</code> of source description in XML form
 *  <li>sourceAlias  : reference name of XML data source
 *  <li>queryURL     : <code>URL</code> of the query doc in XML form
 *  <li>[outputURL]  : <code>URL</code> where result XML should be send (is optional)
 * </ol>
 * <p>
 * The different tasks of:
 * <ul>
 *  <li>reading XML files
 *  <li>verifying their validy due to the wrappers DTDs
 *  <li>building internal representations of the documents
 *  <li>and the actual query mapping
 * </ul>
 * are fulfilled by other classes of this package.
 * <p>
 * <code>XMLWrapper</code>'s only job is to:
 * <ul>
 *  <li>check the correct numbers of parameters
 *  <li>verifying form of URLs
 *  <li>checking connections to http/ftp sources
 *  <li>providing input stream to sources URLs
 * </ul>
 *
 * @author Robert S�semann, <robert.soesemann@student.uni-tuebingen.de>
 * @version 1.0, 23.03.02
 */

public class XMLWrapper
{
  static final String DOMADAPTER = "org.jdom.adapters.XercesDOMAdapter";   // needed to generate JAR
  static final Namespace XSL_NAMESPACE = Namespace.getNamespace("xsl", "http://www.w3.org/1999/XSL/Transform");

  private static final String LOGFILEPATH = "xmwrapper.log";
  private static final boolean DEBUG = true;    //if true also print stacktrace when error
  private static final boolean TOFILE = true;   //if true logfile is created


  /**
   * Prints error messages and usage information on prompt or to logfile
   *
   * @param reason    <code>String</code> error reason
   * @param exception <code>Exception</code> actual exception if it was passed
   */
  static void writeMessage(String reason, Exception exception)
  {
	String message = "\n" + reason + "\n";

	// print out (error) messages directly to prompt
    if(!TOFILE)
	{
	  System.out.println(message);
	  // also show detailed debugging information
	  if(DEBUG && exception != null) exception.printStackTrace();
	}
	else  //write to log file
	{
	  try
	  {
		writer = new PrintWriter(new FileWriter(LOGFILEPATH, true));
		now = new Date();
		writer.println("@[" + now + "] : " + reason);
		if(exception != null) exception.printStackTrace(writer);
		writer.flush();
		writer.close();
	  }
	  catch(IOException ex)
	  { System.out.println("could not write to logfile"); }
	}
  } //writeMessage


  /**
   * Obtains <code>InputStream</code> from a given <code>URL</code>.
   * The URL can be a locator to an ftp, http or local file source.
   * The URL can also contain login/password and port information.
   * This method is used by the whole package whenever data must be read from URL.
   *
   * @param url <code>URL</code> the URL of a data source
   * @return JDOM <code>Document</code>
   * @throws Exception is thrown by subclasses (mostly IO exceptions)
   */
  static InputStream getInputStream(URL url) throws Exception
  {
	InputStream is = null;
	String protocol = "";

	if(url.getProtocol() != null)
	  protocol = url.getProtocol();

	// CASE 1 + 2: local and (secured) http sources are directly handled by JDOM
	if(protocol.equals("file") || protocol.equals("http"))
		is = url.openStream();

	// CASE 3: URL point to FTP upload-enabled server
	else if(protocol.equals("ftp"))
	{
	  int port = 21;
	  if(url.getPort() != -1) port = url.getPort();

	  String host = url.getHost();
	  String path = url.getFile();
	  String dir = path.substring(1, path.lastIndexOf("/"));
	  String file = path.substring(path.lastIndexOf("/") + 1);
	  String user     = "";
	  String password = "";

	  if(url.getUserInfo() != null)
	  {
		java.util.StringTokenizer tokenizer = new java.util.StringTokenizer(url.getUserInfo(), ":");
		user = tokenizer.nextToken();
		password = tokenizer.nextToken();
	  }

	  FTPClient ftp = new FTPClient();

	  // try to establish connection
	  ftp.connect(host);
	  int reply = ftp.getReplyCode();

	  if(!FTPReply.isPositiveCompletion(reply))
	  {
		ftp.disconnect();
		throw new XMLWrapperException("host " + host + " refused connection", -10);
	  }

	  // try to login and get file stream
	  if(!ftp.login(user, password))
	  {
		ftp.logout();
		throw new XMLWrapperException("unable to login to " + host + " with given authentication", -11);
	  }

	  ftp.changeWorkingDirectory(dir);
	  is = ftp.retrieveFileStream(file);

	  ftp.logout();
	} //else if ftp


	// CASE 4: Unsupported protocoll
	else
	  throw new XMLWrapperException(protocol + " is an unsupported protocol", -12);

	return is;
  } //getInputStream


  /**
   * Sends anm XML formated stream to an <code>URL</code>. May be local file,
   * ftp or http.
   *
   * @param doc <code>Document</code> the JDOM Document that hold XML to be send
   * @param url <code>URL</code> to the desired location
   * @throws XMLWrapperException is thrown by subclasses (mostly IO exceptions)tly
   */
  private static void sendDocument(Document doc, URL url) throws Exception
  {
	XMLOutputter xmloutputter = new XMLOutputter();
	xmloutputter.setNewlines(true);
	xmloutputter.setEncoding("ISO-8859-1");
	xmloutputter.setTextNormalize(false);

	String protocol = "";
	String host     = "";
	String path     = "";
	String dir      = "";
	String file     = "";
	String user     = "";
	String password = "";

	// is the case when output should be send to console
	if(url != null)
	{
	  protocol = url.getProtocol();

	  host = url.getHost();
	  path = url.getFile();
	  dir = path.substring(1, path.lastIndexOf("/"));
	  file = path.substring(path.lastIndexOf("/") + 1);

	  if(url.getUserInfo() != null)
	    {
		  java.util.StringTokenizer tokenizer = new java.util.StringTokenizer(url.getUserInfo(), ":");
		  user = tokenizer.nextToken();
		  password = tokenizer.nextToken();
		}
	}

	// CASE 1: URL point to local file
	if(protocol.equals("file"))
	{
		java.io.FileWriter writer = new java.io.FileWriter(url.getPath());
	    xmloutputter.output(doc, writer);
		writer.close();
	}

	else if(protocol.equals("ftp"))
	{
	  int port = 21;
	  if(url.getPort() != -1) port = url.getPort();

	  FTPClient ftp = new FTPClient();

	  // try to establish connection
	  ftp.connect(host);
	  int reply = ftp.getReplyCode();

	  if(!FTPReply.isPositiveCompletion(reply))
	  {
		ftp.disconnect();
		throw new XMLWrapperException("FTP server " + host + " refused connection", -13);
	  } //if

	  // try to login and get file stream
	  if(!ftp.login(user, password))
	  {
		ftp.logout();
		throw new XMLWrapperException("unable to login to " + host + " with given authentication", -14);
	  }

	  ftp.changeWorkingDirectory(dir);
	  java.io.OutputStream os = ftp.storeFileStream(file);

	  xmloutputter.output(doc, os);
	  os.close();
	  ftp.logout();
	} //else if ftp

	// CASE 3: URL point to network location, send result file via PUT
	else if(protocol.equals("http"))
	{
	  // set connection properties
	  HTTPClient.HttpURLConnection con = (HTTPClient.HttpURLConnection) url.openConnection();
	  con.setDoOutput(true);
	  con.setRequestMethod("PUT");
	  con.setRequestProperty("Content-type", "text/xml");

	  int content_length = xmloutputter.outputString(doc).length();
	  con.setRequestProperty("Content-Length", Integer.toString(content_length));

	  java.io.OutputStreamWriter osw = new java.io.OutputStreamWriter(con.getOutputStream());

	  // open connection for JDOM to write
	  con.connect();
	  xmloutputter.output(doc, osw);

	  osw.close();
	  con.disconnect();
	} //else if http

	// CASE 4: Default -> Unsupported protocoll or param not set
	else
	{
	  xmloutputter.setTextNormalize(false);
	  xmloutputter.output(doc, System.out);
	}
  } //sendDocument


  /**
   * <code>main()</code> program for <code>XMLWrapper:</code>
   *
   * Expects as input the following parameters:
   * <p>
   * <ol>
   *  <li>descriptorURL: <code>URL</code> of source description in XML form
   *  <li>sourceAlias  : reference name of XML data source
   *  <li>queryURL     : <code>URL</code> of the query doc in XML form
   *  <li>[outputURL]  : <code>URL</code> where result XML should be send (is optional)
   * </ol>
   * </p>
   * <p>
   * By the use of <code>URL</code> as locator, <code>XMLWrapperL</code> is
   * able to reveive and send XML files from and to varouis locations, e.g.:
   * <ul>
   *  <li>open and save local files, by the use of <code>file:/...</code> protocol
   *  <li>download and upload files from ftp servers, by the use of <code>ftp:/user:password@...</code> protocal
   *  <li>GET and PUT from http server, by the use of <code>http:/user:password@...</code> protocol
   * </ul>
   * </p>
   *
   * @param args <code>String[]</code> Parameter string array
   */
  public static void main(String[] args)
  {
	// write logfile header
	String params = "";
	for(int i=0; i<args.length; i++) params += args[i] + " ";
	writeMessage("XMLWrapper started with params: " + params, null);

	int code; //holds error codes passed by other classes

	// handle simple parameter errors
	if(args.length < 3 || args.length > 4)
	{
	  writeMessage("Error occured due to invalid number of parameters", null);
	  System.exit(-1);
	}

	// handle invalid or malformed parameters
	else
	{
	  // save output URL
	  try
	  {
		descriptorURL = new URL(args[0]);
		queryURL = new URL(args[2]);

		if(args.length==4) outputURL = new URL(args[3]);
	  }
	  catch(java.net.MalformedURLException ex)
	  {
		writeMessage("Error occured while connect to parameter URL [" + ex.getMessage() + "]", ex);
		System.exit(-2);
	  }

	  sourceAlias   = args[1];

	  // build internal representation of SourceDescriptor document
	  try
	  { descriptor = new XMLSourceDescriptor(getInputStream(descriptorURL)); }
	  catch(Exception ex)
	  {
		writeMessage("Error occurred while accesing SourceDescriptor [" + ex.getMessage() + "]", ex);
		if(ex instanceof XMLWrapperException) code = ((XMLWrapperException) ex).getCode();
		else code = -3;
		System.exit(code);
	  }

	  // build internal representation of CommonQuery document
	  try
	  { query = new CommonQuery(getInputStream(queryURL)); }
	  catch(Exception ex)
	  {
		writeMessage("Error occurred while accessing CommonQuery [" + ex.getMessage() + "]", ex);
		if(ex instanceof XMLWrapperException) code = ((XMLWrapperException) ex).getCode();
		else code = -4;
		System.exit(code);
	  }

	  // invoke QueryMapper to perform mapping to obtain resultDoc
	  QueryMapper querymapper = new QueryMapper(descriptor);

	  try
	  {	resultDoc = querymapper.executeQuery(query); }
	  catch(Exception ex)
	  {
		writeMessage("Error occurred while mapping CommonQuery to XSLT [" + ex.getMessage() + "]", ex);
		if(ex instanceof XMLWrapperException) code = ((XMLWrapperException) ex).getCode();
		else code = -6;
		System.exit(code);
	  }

	  // write result to user defined output URL
	  try
	  { sendDocument(resultDoc, outputURL); }
	  catch(Exception ex)
	  {
		writeMessage("Error occured while writing output to " + outputURL + " [" + ex.getMessage() + "]", ex);
		if(ex instanceof XMLWrapperException) code = ((XMLWrapperException) ex).getCode();
		else code = -7;
		System.exit(code);
	  }

	  writeMessage("XMLWrapper exits succesfully", null);
	  System.exit(0);
	}
  } //main


  /* input parameters */
  private static URL descriptorURL;
  private static String sourceAlias;
  private static URL queryURL;
  private static URL outputURL;

  /* other helper fields */
  private static File logFile;
  private static PrintWriter writer;
  private static Date now;

  private static Document resultDoc;
  private static XMLSourceDescriptor descriptor;
  private static CommonQuery query;

} //XMLWrapper