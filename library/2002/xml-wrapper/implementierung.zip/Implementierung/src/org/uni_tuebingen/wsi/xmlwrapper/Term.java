package org.uni_tuebingen.wsi.xmlwrapper;

import java.util.*;
import org.jdom.Element;
import org.jdom.Attribute;

/**
 * An instance of <code>Term</code> represents a <code><term></code>
 * element in a common query used by the <code>XMLWrapper</code> application.
 *
 * The constructor constructs this internal representation after calling parser
 * methods on the incoming tree fragment, that check the syntax of the
 * <code>Term</code> subcomponents.
 *
 * @author Robert S�semann, <robert.soesemann@student.uni-tuebingen.de>
 * @version 1.0, 23.03.02
 */

public class Term
{
  /* constants holding the valid values for a term's attributes */
  private static final String[] VALIDFIELD = {"any","dc:title","dc:creator",
			   "dc:subject","dc:description","dc:publisher","dc:contributor",
			   "dc:date","dc:type","dc:format","dc:identifier","dc:source",
			   "dc:language","dc:relation","dc:coverage","dc:rights","any"};
  private static final String[] VALIDVALUE = {"REQUIRED"};
  private static final String[] VALIDRELATION = {"eq","lt","gt","leq","geq","neq","ct","nct","eq"};
  private static final String[] VALIDREFINEMENT = {"IMPLIED"};
  private static final String[] VALIDTRUNCATION = {"none","left","right","both","none"};
  private static final String[] VALIDCASE_SENSITIVE = {"no","yes","no"};
  private static final String[] VALIDENCODING = {"IMPLIED"};
  private static final String[] VALIDMODIFIER = {"IMPLIED"};


  /**
   * Parses the incoming XML tree fragment (=an element) for correct <code><boolean></code>
   * syntax and builds an internal representation.
   * To parse its attributes <code>parseAttribute()</code> is called.
   *
   * @param termElement a JDOM <code>Element</code> that holds a tree fragment
   * @throws XMLWrapperException is thrown when syntax error occurs
   */
  public Term(Element termElement) throws XMLWrapperException
  {
	// term element is required to be EMPTY
	if(termElement.hasChildren())
	  throw new XMLWrapperException("term elements must be empty", -43);

	field = parseAttribute(termElement, "field", VALIDFIELD);
	relation = parseAttribute(termElement, "relation", VALIDRELATION);
	value = parseAttribute(termElement, "value", VALIDVALUE);
	refinement = parseAttribute(termElement, "refinement", VALIDREFINEMENT);
	truncation = parseAttribute(termElement, "truncation", VALIDTRUNCATION);
	case_sensitive = parseAttribute(termElement, "case-sensitive", VALIDCASE_SENSITIVE);
	encoding = parseAttribute(termElement, "encoding", VALIDENCODING);
	modifier = parseAttribute(termElement, "modifier", VALIDMODIFIER);
  } //constructor


  /**
   * Generic parser and setter method for all internal representations of a terms attributes.
   * This is only called by the constructor to copy the information of an JDOM tree fragment.
   *
   * @param termElement   JDOM <code>Element</code> holds a term in a <code>CommonQuery</code>
   * @param name          <code>String</code> the attributes name, whose value should be copied
   * @param valueRange    <code>String[]</code> constant that hold information about the attributes syntax
   *
   * @throws XMLWrapperException is thrown when syntax error occurs
   * @return <code>String</code> parsed attribute value
   */
  public String parseAttribute(Element termElement, String name, String[] valueRange) throws XMLWrapperException
  {
	Attribute attribute = termElement.getAttribute(name);
	String value = "";
	String tmp = "";

	if(attribute==null && valueRange[0]=="REQUIRED")
	  throw new XMLWrapperException("term is missing required " + name + " attribute", -44);
	else
	{
	  String defaultValue = valueRange[0];

	  if(attribute==null && defaultValue=="IMPLIED")
	    tmp = "";
	  else if(attribute==null && defaultValue!="IMPLIED")     // default value can be set
	     tmp = defaultValue;
	  else                         // check provided value for validity
	  {
		ArrayList valueList = new ArrayList(Arrays.asList(valueRange));
		valueList.remove(0);  // remove IMPLIED/REQUIRED
		value = attribute.getValue();

		if(valueList.contains(value) || valueList.isEmpty())
		  tmp = value;
		else
		  throw new XMLWrapperException("\"" + value + "\" can not be value of attribute " + name, -45);
	  } //else
	} //else

	return tmp;
  } //setAttribute


  /**
   * This method is part of the recursive composition of the XSLT expression, that
   * maps the common query's condition to XSLT syntax.
   * The booleans subcomponents are combined by the XSLT counterpart of the common
   * query's operator.
   * The string representation of the subcomponents themselves is maintained by calling
   * their <code>toXSLTPattern()</code> methods
   *
   * @param sofar <code>String</code> that hold part of the XSLT pattern, that was
   * generated yet during recursive calls of this method
   * @param sourceProperties <code>HashMap</code> holding essential information needed
   * mapping the common query's generic names to the actuals XSLT and source language.
   * The information how to map the field names is provided by the sourceProperties
   * <code>HashMap</code>.
   *
   * @return XSLT conform, source specific <code>String</code> representation of this <term>.
   * @throws XMLWrapperException is thrown when syntax error occurs
   */
  public String toXSLTPattern(String sofar, HashMap sourceProperties) throws XMLWrapperException
  {
    // split mapto-field of any
    StringTokenizer tokenizer;

	/* (1) Handle 'field' : check if corresponding property is found */
	if(sourceProperties.containsKey(field))
	{
	  Property p = (Property) sourceProperties.get(field);
	  mappedField = p.getMapto();
      tokenizer = new StringTokenizer(mappedField, ",");
	}
	else
	  throw new XMLWrapperException("field '" + field +"' in common query has no counterpart in source", -46);

	/* (2) Handle 'relation' attribute : map relation to XPath equivalent */
	if(relation.equals("lt")) relation = " < ";
	else if(relation.equals("gt")) relation = " > ";
	else if(relation.equals("leq")) relation = " <= ";
	else if(relation.equals("geq")) relation = " >= ";
	else if(relation.equals("neq")) relation = " != ";
	else relation = "=";

	/* (3) Handle 'case-insensitiveness' attribute : make field and value lowercase  */
	originalvalue = ".";    // leave it like it is
	value = "'" + value + "'";

	if(case_sensitive.equals("no"))
	{
	  value = "translate(" + value + ", $UPPERCASE, $LOWERCASE)";
	  originalvalue = "translate(., $UPPERCASE, $LOWERCASE)";
	}
	// also normalize spaces in and around field
	originalvalue = "normalize-space(" + originalvalue + ")";

	/* (4) Handle value and truncation attribute : truncation only make sense with 'eq' or 'neq' */
	if(!(relation.equals("=") || relation.equals("!=")) && !(truncation.equals("none")))
	  throw new XMLWrapperException("relation '" + relation +"' only allowed with truncation='none'", -47);
	else
	{
	  if(truncation.equals("both"))
		condition = "[contains(" + originalvalue + ", " + value + ")]";
	  else if(truncation.equals("right"))
	    condition = "[starts-with(" + originalvalue + ", " + value + ")]";
	  else if(truncation.equals("left"))
		condition = "[substring(" + originalvalue + ", string-length(.) - string-length('" + value + "') + 1)=" + value + "]";
	  else
		condition = "[" + originalvalue + " " + relation + " " + value + "]";
	}

    //if fieldname is any, maybe it maps to more than one element/attribute
    while(tokenizer.hasMoreTokens())
    {
      //check element and attribute values
      mappedField = tokenizer.nextToken().trim();
      sofar += ".//" + mappedField + condition + " or .//@" + mappedField + condition;

      if(tokenizer.hasMoreTokens())
	    sofar += " or ";
    }

	return "(" + sofar + ")";
  } //toXSLTPattern


  /* holds the components of a <term> */
  private String field;
  private String relation;
  private String value;
  private String refinement;
  private String truncation;
  private String case_sensitive;
  private String encoding;
  private String modifier;

  /* fields used for term-resolving */
  private String originalvalue;
  private String mappedField;
  private String condition;

} //Term