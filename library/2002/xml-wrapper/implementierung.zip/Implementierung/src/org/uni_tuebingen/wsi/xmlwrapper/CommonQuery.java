package org.uni_tuebingen.wsi.xmlwrapper;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.DOMBuilder;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;

/**
 * An instance of <code>CommonQuery</code> represents a <code><query></code>
 * element in a common query uses by the <code>XMLWrapper</code> application.
 *
 * The constructor constructs this internal representation after calling parser
 * methods on the incoming tree fragment, that check the syntax of the
 * <code>CommonQuery</code> subcomponents. *
 *
 * @author Robert S�semann, <robert.soesemann@student.uni-tuebingen.de>
 * @version 1.0, 23.03.02
 */

public class CommonQuery
{
  /**
   * The incoming <code>InputStream</code>is converted to an JDOM document
   * and parsed for correct <code><query></code> syntax to builds an internal
   * representation.
   * To parse the common query's subcomponents (term, boolean) instances of
   * <code>Term</code> and <code>Boolean</code> are created.
   *
   * @param is <code>InputStream</code> that holds an XML Document
   * @throws Exception is thrown by JDOM methods or when syntax error occurs
   */
  public CommonQuery(InputStream is) throws Exception
  {
	DOMBuilder builder = new DOMBuilder(XMLWrapper.DOMADAPTER);
	Document validQueryDoc = builder.build(is);
	Element root = validQueryDoc.getRootElement();
	if(!(root.getName().equals("query")))
	  throw new XMLWrapperException("root element of query is not <query>", -40);

	List children = root.getChildren();
	if(children.size() != 1)
	  throw new XMLWrapperException("<query> holds more than one term or boolean child element", -41);

	Element child = (Element) children.get(0);
	termOrBoolean = parseTermOrBoolean(child);
  } //constructor


  /**
   * As helper method of the constructor, <code>parseTermOrBoolean</code> calles the
   * required parsing methods for a <code>CommonQuery</code>'s subcomponents.
   *
   * @param subelement an JDOM <code>Element</code> that either hold a <term> or <boolean> tree fragment
   * @return <code>Object</code>, that wraps <code>Term</code> or <code>Boolean</code> instance
   * @throws XMLWrapperException is thrown when syntax error occurs
   */
  private Object parseTermOrBoolean(Element subelement) throws XMLWrapperException
  {
	Object tmp;
	if(subelement.getName().equals("term"))
	  tmp = new Term(subelement);
	else if(subelement.getName().equals("boolean"))
	  tmp = new Boolean(subelement);
	else
	  throw new XMLWrapperException(subelement.getName() + " is an invalid child of <query>", -42);

	return tmp;
  } //parseTermOrBoolean


  /**
   * This method is part of the recursive composition of the XSLT expression, that
   * maps the common query's condition to XSLT syntax.

   * The string representation of the subcomponents themselves is maintained by calling
   * their <code>toXSLTPattern()</code> methods
   *
   * @param sofar <code>String</code> that hold part of the XSLT pattern, that was
   * generated yet during recursive calls of this method
   * @param sourceProperties <code>HashMap</code> holding essential information needed for calling
   * that method on a <code>Term</code> element (see.: <code>Term</code> javadoc)
   *
   * @return XSLT conform, source specific <code>String</code> representation of this <boolean>
   * @throws XMLWrapperException needed to pass Exception that can be thrown by
   * calling that method on a <code>Term</code> elementby a <code>Term</code>
   */
  public String toXSLTPattern(String sofar, HashMap sourceProperties) throws XMLWrapperException
  {
	if(termOrBoolean instanceof Term)
	  return ((Term) termOrBoolean).toXSLTPattern(sofar, sourceProperties);
	else //must be Boolean
	  return ((Boolean) termOrBoolean).toXSLTPattern(sofar, sourceProperties);
  } //toXSLTPattern


  /* holds the component of a <query> */
  private Object termOrBoolean;

} //CommonQuery