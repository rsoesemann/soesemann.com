package org.uni_tuebingen.wsi.xmlwrapper;

import java.util.ArrayList;
import java.util.Iterator;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.DocType;

/* for Xalan Java XSLT processor */
import org.jdom.transform.*;
import javax.xml.transform.*;

/**
 * An instance of <code>XMLSourceFlattener</code> hold a JDOM document representation of
 * an XSLT stylesheet. This stylesheet function is to make sure that all the
 * requested properties can be found in the subtree of the informational unit.
 * (e.g. when I am searching for articles in a magazine database, the property
 * issue number is not part of an article's subtree but of its ancestor <issue>)
 * <p>
 * This flattening is done, by creating a new temporary document which only holds
 * elements of the 'infounit' type. Additionally to their original attributes and
 * descendant nodes, required super-tree elements/attributes are copied into this element.
 * (<issue>'s <number> element would now be a direct child of <article>)
 *
 * As XSLT transformer Apache's Xalan-J is used.
 *
 * @author Robert S�semann, <robert.soesemann@student.uni-tuebingen.de>
 * @version 1.0, 23.03.02
 */

public class XMLSourceFlattener
{
  /**
   * Creates an <code>XMLSourceFlattener</code> for a certain preflattened source and its searchable informational unit.
   *
   * @param originalSource <code>JDOMSource</code> that hold the original source in an format suitable for Xalan
   * @param infounit <code>String</code> that holds the document's searchable informational unit
   */
  public XMLSourceFlattener(JDOMSource originalSource, String infounit)
  {
	source = originalSource;
        infoUnit = infounit;
  } //constructor


  /**
   * Creates an  XSLT stylesheet that returns a flattened original source document.
   * This method holds a generic framework which is customized for a specific query
   * by its <code>outerProperties</code> paramter.
   *
   * @param outerProperties <code>ArrayList</code> holds the names of all the sources
   *        properties (=attributes/elements) that lie not in the subtree of the document's
   *        informational unit, but in its super-tree
   * @return JDOM Document representation of this XSLT stylesheet
   */
  private Document getXSLTDocument(ArrayList outerProperties)
  {
	//root element
	Element transform = new Element("transform", "xsl",  "http://www.w3.org/1999/XSL/Transform");
	transform.setAttribute("version", "1.0");

	//output element
	Element output = new Element("output", XMLWrapper.XSL_NAMESPACE);
	output.setAttribute("method", "xml");
	transform.addContent(output);

	//root copy template
	Element identityTemplate = new Element("template", XMLWrapper.XSL_NAMESPACE);
	identityTemplate.setAttribute("match", "node() | @*");
	Element identity_copy = new Element("copy", XMLWrapper.XSL_NAMESPACE);
	Element apply_templates = new Element("apply-templates", XMLWrapper.XSL_NAMESPACE);
	apply_templates.setAttribute("mode", "notroot");
	identity_copy.addContent(apply_templates);
	identityTemplate.addContent(identity_copy);
	transform.addContent(identityTemplate);

	// flatten template
	Element flattenTemplate = new Element("template", XMLWrapper.XSL_NAMESPACE);
	flattenTemplate.setAttribute("match", infoUnit);
	flattenTemplate.setAttribute("mode", "notroot");
	transform.addContent(flattenTemplate);
	Element flatten_copy = new Element("copy", XMLWrapper.XSL_NAMESPACE);
	flattenTemplate.addContent(flatten_copy);

	// copy outerproperties that are attributes first
	Iterator iterator = outerProperties.iterator();
	while(iterator.hasNext())
	{
	  String outerproperty = (String) iterator.next();

	  Element attribute_if = new Element("if", XMLWrapper.XSL_NAMESPACE);
	  attribute_if.setAttribute("test", "ancestor-or-self::node()[@" + outerproperty + "]");
	  flatten_copy.addContent(attribute_if);
	  Element attribute_copy = new Element("attribute", XMLWrapper.XSL_NAMESPACE);
	  attribute_copy.setAttribute("name", outerproperty);
	  attribute_if.addContent(attribute_copy);
	  Element value_of = new Element("value-of", XMLWrapper.XSL_NAMESPACE);
	  value_of.setAttribute("select", "ancestor-or-self::node()/@" + outerproperty);
	  attribute_copy.addContent(value_of);
	}

	// now copy outerproperties that are elements
	iterator = outerProperties.iterator();
	while(iterator.hasNext())
	{
	  String outerproperty = (String) iterator.next();

	  Element ancestor_copy = new Element("copy-of", XMLWrapper.XSL_NAMESPACE);
	  ancestor_copy.setAttribute("select", "ancestor::node()/" + outerproperty);
	  flatten_copy.addContent(ancestor_copy);
	}

	Element self_copy = new Element("copy-of", XMLWrapper.XSL_NAMESPACE);
	self_copy.setAttribute("select", "*");
	flatten_copy.addContent(self_copy);

	// text consumer template
	Element textTemplate = new Element("template", XMLWrapper.XSL_NAMESPACE);
	textTemplate.setAttribute("match", "text()");
	transform.addContent(textTemplate);

	return new Document(transform);
  } //getXSLTDocument


  /**
   * Creates an  XSLT stylesheet that returns a flattened original source document.
   * This method holds a generic framework which is customized for a specific query
   * by its <code>outerProperties</code> paramter. (actually this is a jacket method
   * which calls other private methods to perform the transformation)
   *
   * @param outerProperties <code>ArrayList</code> holds the names of all the sources
   *        properties (=attributes/elements) that lie not in the subtree of the document's
   *        informational unit, but in its super-tree
   * @return JDOM Document representation of this XSLT stylesheet
   */
  public Document flatten(ArrayList outerProperties) throws Exception
  {
	// set up Xalan Processor
	TransformerFactory transformerFactory = TransformerFactory.newInstance();

	// create Transformer for mapped query
	JDOMSource querySource = new JDOMSource(getXSLTDocument(outerProperties));
	Templates queryTemplate = transformerFactory.newTemplates(querySource);
	Transformer processor = queryTemplate.newTransformer();

	// perform XSLT transformation and get JDOM doc
	JDOMResult result = new JDOMResult();
	processor.transform(source, result);

	return result.getDocument();
  } //flatten

  private JDOMSource source;
  private String infoUnit;
 } //XMLSourceFlattener