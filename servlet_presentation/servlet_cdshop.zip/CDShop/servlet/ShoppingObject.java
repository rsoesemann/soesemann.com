// Autor: Horst Rechner

public class ShoppingObject
{
	private int id;
	private int anzahl;

	public ShoppingObject(int gotId, int gotAnzahl)
	{
		id = gotId;
		anzahl = gotAnzahl;
	}

	public ShoppingObject()
	{
		id = 0;
		anzahl = 0;
	}

	public void setId(int gotId)
	{
		id = gotId;
	}

	public void setAnzahl(int gotAnzahl)
	{
		anzahl = gotAnzahl;
	}

	public int getId()
	{
		return id;
	}

	public int getAnzahl()
	{
		return anzahl;
	}

}
